package juaracoding;

import com.juaracoding.drivers.DriverSingleton;
import com.juaracoding.pages.LoginAndChart;
import com.juaracoding.utils.Constant;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TesDay17 {

//    I Gede Arya Krisnadi
    private WebDriver driver;
    private LoginAndChart loginAndChart;
    @BeforeClass
    public void setUp(){
        DriverSingleton.getInstance(Constant.CHROME);
        driver = DriverSingleton.getDriver();
        driver.get(Constant.url);
        loginAndChart = new LoginAndChart();
    }
    @AfterClass
    public void finish(){
        DriverSingleton.delay(5);
        DriverSingleton.closeObjectInstance();
    }

    @Test (priority = 1)
    public void validLogin(){
        loginAndChart.loginPage("arya99", "aryakrinadi123");
        Assert.assertEquals(loginAndChart.getTextDashboard(), "MY ACCOUNT");
        System.out.println("Test Case Valid Login");
    }

    @Test (priority = 2)
    public void addProduct(){
        loginAndChart.tesMenu();
        loginAndChart.pilihProduct();
        Assert.assertEquals(loginAndChart.validasiAddProduct(), "View cart");
    }










}
