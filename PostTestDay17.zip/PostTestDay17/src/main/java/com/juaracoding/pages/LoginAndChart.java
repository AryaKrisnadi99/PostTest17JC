package com.juaracoding.pages;

import com.juaracoding.drivers.DriverSingleton;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LoginAndChart {
    private WebDriver driver;

    public LoginAndChart(){
        this.driver = DriverSingleton.getDriver();
        PageFactory.initElements(driver, this);
    }

    //Locator use Page Factory
    @FindBy(xpath = "//a[normalize-space()='My Account']")
    private WebElement myAccount;

    @FindBy(xpath = "//input[@id='username']")
    private WebElement username;

    @FindBy(xpath = "//input[@id='password']")
    private WebElement password;
    @FindBy(xpath = "//button[@name='login']")
    private WebElement btnlogin;

    @FindBy(xpath = "//h1[@class='page-title']")
    private WebElement profile;

    //Add Chart
    @FindBy(xpath = "//*[@id=\"noo-site\"]/header/div[2]/div/div/div/div/a")
    private WebElement shop;

    @FindBy(xpath = "//a[normalize-space()='pink drop shoulder oversized t shirt']")
    private WebElement product;

    @FindBy(xpath = "//button[normalize-space()='Add to cart']")
    private WebElement btnAddProduct;
    @FindBy(xpath = "//a[@class='button wc-forward']")
    private WebElement checkChart;


    public void loginPage(String username, String password){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,10000)");
        myAccount.click();
        js.executeScript("window.scrollBy(0,10000)");
        this.username.sendKeys(username);
        this.password.sendKeys(password);
        btnlogin.click();
    }

//Validasi login
    public String getTextDashboard(){
        return profile.getText();
    }

    public void tesMenu(){
        shop.click();
    }

    public void pilihProduct(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("window.scrollBy(0,5000)");
        product.click();
        js.executeScript("window.scrollBy(0,5000)");
        Select opsi1 = new Select(driver.findElement(By.id("pa_color")));
        opsi1.selectByValue("pink");
        Select opsi2 = new Select(driver.findElement(By.id("pa_size")));
        opsi2.selectByValue("36");
        btnAddProduct.click();
    }

    public String validasiAddProduct(){
        return checkChart.getText();
    }

}
